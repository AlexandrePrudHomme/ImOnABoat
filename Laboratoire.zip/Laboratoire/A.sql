/* 1. Find the name and ages of all sailors */
SELECT sailors.sname, sailors.age
FROM SAILORS;

/* 2. Find the distinct names and ages of all sailors */
SELECT DISTINCT sailors.sname, sailors.age
FROM SAILORS;

/* 3. Find all sailors with a rating above 7. */
SELECT sailors.sid, sailors.sname, sailors.rating, sailors.age
FROM SAILORS
WHERE sailors.rating > 7;

/* 4. Find the names of sailors who have reserved boat number 103 */
SELECT sailors.sname
FROM SAILORS
INNER JOIN RESERVES ON sailors.sid = reserves.sid
WHERE reserves.bid = 103;

/* 5. Find the names of sailors who have reserved a red boat */
SELECT sailors.sname
FROM SAILORS
INNER JOIN RESERVES ON sailors.sid = reserves.sid
INNER JOIN BOATS ON reserves.bid = boats.bid
WHERE boats.color = 'Red';

/* 6. Find the colors of boats reserved by Lubber */
SELECT DISTINCT boats.color
FROM BOATS
INNER JOIN RESERVES ON boats.bid = reserves.bid
INNER JOIN SAILORS ON reserves.sid = sailors.sid
WHERE sailors.sname = 'Lubber';

/* 7. Find the names of sailors who have reserved at least one boat */
SELECT sailors.sname
FROM sailors
INNER JOIN reserves ON sailors.sid = reserves.sid;

/* 8. Compute increments for the ratings of persons who have sailed two different
boats on the same day */
SELECT sailors.sname, sailors.rating + 1
FROM sailors
INNER JOIN reserves r1 ON sailors.sid = r1.sid
INNER JOIN reserves r2 ON sailors.sid = r2.sid
WHERE r1.day = r2.day AND r1.bid <> r2.bid;

/* 9. Find the ages of sailors whose name begins and ends with B and has at least three
characters */
SELECT sailors.age
FROM sailors
WHERE sailors.sname LIKE 'B_%b';

/* 10. Find the names of sailors who have reserved a red or a green boat. */
SELECT sailors.sname
FROM sailors
INNER JOIN reserves ON sailors.sid = reserves.sid
INNER JOIN boats ON reserves.bid = boats.bid
WHERE (boats.color = 'Red') or (boats.color = 'Green');

/* 11. Find the names of sailors who have reserved both a red and a green boat. */
SELECT s1.sname
FROM sailors s1, reserves r1, boats b1
WHERE s1.sid = r1.sid AND r1.bid = b1.bid AND b1.color = 'Red'
INTERSECT
SELECT s2.sname
FROM sailors s2, reserves r2, boats b2
WHERE s2.sid = r2.sid AND r2.bid = b2.bid AND b2.color = 'Rreen';

/* 12. Find the sids of all sailors who have reserved red boats but not green boats. */
SELECT s1.sid
FROM sailors s1, reserves r1, boats b1
WHERE s1.sid = r1.sid AND r1.bid = b1.bid AND b1.color = 'Red'
EXCEPT
SELECT s2.sid
FROM sailors s2, reserves r2, boats b2
WHERE s2.sid = r2.sid AND r2.bid = b2.bid AND b2.color = 'Green';

/* 13. Find all sids of sailors who have rating of 10 or reserved boat 104 */
SELECT sailors.sid
FROM sailors
WHERE sailors.rating = 10
UNION
SELECT reserves.sid
FROM reserves
WHERE reserves.bid = 104;

/* 14. Find the average age of all sailors. */
SELECT AVG(sailors.age)
FROM sailors;

/* 15. Find the average age of sailors with a rating of 10 */
SELECT AVG(sailors.age)
FROM sailors
WHERE sailors.rating = 10;

/* 16. Find the name and age of the oldest sailor */
SELECT sailors.sname, sailors.age
FROM sailors
WHERE sailors.age = (SELECT MAX(sailors.age)
					FROM sailors);

/* 17. Count the number of sailors */
SELECT COUNT(sailors.sid)
FROM sailors;

/* 18. Count the number of different sailor names.*/
SELECT COUNT(DISTINCT sailors.sname)
FROM sailors;

/* 19. Find the age of the youngest sailor for each rating level.*/
SELECT MIN(sailors.age), sailors.rating
FROM sailors
GROUP BY sailors.rating;

/* 20. Find the age of the youngest sailor who is eligible to vote (i.e., is at least 18 years
old) for each rating level with at least two such sailors. */
SELECT MIN(sailors.age), sailors.rating
FROM sailors
WHERE sailors.age >= 18
GROUP BY sailors.rating
HAVING COUNT(sailors) >= 2;