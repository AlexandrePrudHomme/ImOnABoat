/* 1 */
/* Aucune stratégie nécessaire */

/* 2 */
CREATE INDEX SnameOfSailorsIndex ON sailors USING btree (sname);
CLUSTER sailors USING SnameOfSailorsIndex;

/* 3 */
CREATE INDEX RatingOfSailorsIndex ON sailors USING btree (rating);
CLUSTER sailors USING RatingOfSailorsIndex;

/* 4 */
CREATE INDEX BidOfReservesIndex ON reserves USING hash (bid);

/* 5 */
CREATE INDEX ColorOfBoatsIndex ON boats USING btree (color);
CLUSTER boats USING ColorOfBoatsIndex;
CREATE INDEX BidOfReservesIndex ON reserves USING hash (bid);
CREATE INDEX SidOfSailorsIndex ON sailors USING hash (sid);

/* 6 */
CREATE INDEX NameOfSailorsIndex ON sailors USING hash (sname);
CREATE INDEX SidOfReservesIndex ON reserves USING hash (sid);
CREATE INDEXBidOfBoatsIndex ON boats USING hash (bid);

/* 7 */
CREATE INDEX SidOfSailorsIndex ON sailors USING hash (sid);

/* 8 */
CREATE INDEX SidOfReservesIndex ON reserves USING hash (sid);

/* 9 */
CREATE INDEX SnameOfSailorsIndex ON sailors USING btree (sname);
CLUSTER sailors USING SnameOfSailorsIndex;

/* 10 */
CREATE INDEX ColorOfBoatsIndex ON boats USING hash (color);
CREATE INDEX BidOfReservesIndex ON reserves USING hash (bid);
CREATE INDEX SidOfReservesIndex ON reserves USING hash (sid);

/* 11 */
CREATE INDEX ColorOfBoatsIndex ON boats USING hash (color);
CREATE INDEX BidOfReservesIndex ON reserves USING hash (bid);
CREATE INDEX SidOfReservesIndex ON reserves USING hash (sid);

/* 12 */
CREATE INDEX ColorOfBoatsIndex ON boats USING hash (color);
CREATE INDEX BidOfReservesIndex ON reserves USING hash (bid);
CREATE INDEX SidOfReservesIndex ON reserves USING hash (sid);

/* 13 */
CREATE INDEX RatingOfSailorsIndex ON sailors USING hash (rating);
CREATE INDEX bidOfReservesIndex ON reserves USING hash (bid);

/* 14 */
/* Aucune stratégie nécessaire */

/* 15 */
CREATE INDEX RatingOfSailorsIndex ON sailors USING hash (rating);

/* 16 */
CREATE INDEX AgeOfSailorsIndex ON sailors USING btree (age);
CLUSTER sailors USING AgeOfSailorsIndex;

/* 17 */
CREATE INDEX SidOfSailorsIndexBtree ON sailors USING btree (sid);
CLUSTER sailors USING SidOfSailorsIndexBtree;

/* 18 */
CREATE INDEX SidOfSailorsIndex ON sailors USING btree (sid);
CLUSTER sailors USING SidOfSailorsIndex;

/* 19 */
CREATE INDEX RatingOfSailorsIndex ON sailors USING btree (rating);
CLUSTER sailors USING RatingOfSailorsIndex;

/* 20 */
CREATE INDEX AgeOfSailorsIndex ON sailors USING btree (age);
CLUSTER sailors USING AgeOfSailorsIndex;