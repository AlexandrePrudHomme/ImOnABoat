Alexandre Prud'Homme 7293804
Julien Desautels 7331746
CSI 3530
Lab 1, 2

Ce dossier contient les 5 fichiers du laboratoire 1, 2 qui sont:

1. README.txt -> le fichier d'instructions
2. Rapport.docx -> le rapport du laboratoire qui répond les questions A, B, C et D
3. A.sql -> code source de la partie A, les requêtes
4. B.sql -> code source de la partie B, remplissage des tableaux
5. D.sql -> code source de la partie D, l'optimisation par indexage
